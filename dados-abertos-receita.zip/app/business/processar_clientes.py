from services.cliente_service import ClienteService
from utils.json_utils import carregar_clientes
from core.logger import logger


def executar():
    logger.info("Iniciando processamento")

    clientes = carregar_clientes()

    service = ClienteService()

    for cliente in clientes:
        try:
            service.processar(cliente)

        except Exception as e:
            logger.exception(f"Erro ao processar cliente {cliente['id']}: {e}")

    logger.info("Processamento finalizado")
