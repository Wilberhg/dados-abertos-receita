from app.core.paths import (
    RAW_DIR,
    EXTRACTED_DIR,
    CONVERTED_DIR,
)

from app.services.monthly_service import (
    MonthlyPipeline,
)


def main():
    data_base = "2026-05"
    raw_dir = RAW_DIR / data_base
    extracted_dir = EXTRACTED_DIR / data_base
    converted_dir = CONVERTED_DIR / data_base
    extracted_dir.mkdir(
        parents=True,
        exist_ok=True,
    )
    converted_dir.mkdir(
        parents=True,
        exist_ok=True,
    )
    pipeline = MonthlyPipeline(
        raw_dir,
        extracted_dir,
        converted_dir,
    )
    pipeline.run()


if __name__ == "__main__":
    main()
