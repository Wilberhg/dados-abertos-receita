def main():
    print("Hello from dados-abertos-receita!")


if __name__ == "__main__":
    main()
