from pathlib import Path
from app.infra.files.file_discovery import arquivos_pendentes
from app.infra.files.zip_extractor import ZipExtractor
from app.infra.files.parquet_converter import CsvToParquetConverter


class MonthlyPipeline:

    def __init__(
        self,
        raw_dir: Path,
        extracted_dir: Path,
        converted_dir: Path,
    ):
        self.raw_dir = raw_dir
        self.extracted_dir = extracted_dir
        self.converted_dir = converted_dir
        self.extractor = ZipExtractor()
        self.converter = CsvToParquetConverter()

    def run(self):
        self.extract_zips()
        self.convert_csvs()

    def extract_zips(self):
        zip_files = list(self.raw_dir.rglob("*.zip"))
        csv_files = list(self.extracted_dir.rglob("*.csv"))
        pending = arquivos_pendentes(
            zip_files,
            csv_files,
        )
        for file in pending:
            self.extractor.process(
                file,
                self.extracted_dir,
            )

    def convert_csvs(self):
        csv_files = list(self.extracted_dir.rglob("*.csv"))
        parquet_files = list(self.converted_dir.rglob("*.parquet"))
        pending = arquivos_pendentes(
            csv_files,
            parquet_files,
        )
        for file in pending:
            self.converter.process(
                file,
                self.converted_dir,
            )
