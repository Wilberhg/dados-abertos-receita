import httpx
from fake_useragent import UserAgent
from typing import List
from xml.etree import ElementTree as ET


class ApiDadosAbertos:
    BASE_URL = "https://arquivos.receitafederal.gov.br"
    CAMINHO_MENSAL = f"{BASE_URL}/public.php/dav/files/YggdBLfdninEJX9"
    USER_AGENT = UserAgent()
    HEADERS = {
        "accept": "text/plain,application/xml",
        "user-agent": USER_AGENT.chrome,
        "Content-Type": "text/plain;charset=UTF-8",
    }

    def consultar_data_base(self, data: str):
        response = httpx.request(
            "PROPFIND", f"{self.CAMINHO_MENSAL}/{data}", headers=self.HEADERS
        )
        try:
            response.raise_for_status()
        except:
            return None
        else:
            return ET.fromstring(response.text)

    def baixa_base_empresas(self, link_arquivo: List[str]):
        headers = self.HEADERS.copy()
        headers.pop("accept")
        headers.pop("Content-Type")
        response = httpx.get(
            f"{self.BASE_URL}{link_arquivo}", headers=headers, timeout=3600.0
        )
        try:
            response.raise_for_status()
        except:
            return False
        else:
            return response.content


if __name__ == "__main__":
    obj = ApiDadosAbertos()
    obj.consultar_data_base("2025-05")
