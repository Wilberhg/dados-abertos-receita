from services.api_service import ApiService
from repositories.cliente_repository import ClienteRepository
from core.logger import logger


class ClienteService:

    def __init__(self):
        self.api = ApiService()
        self.repository = ClienteRepository()

    def processar(self, cliente):

        logger.info(f"Processando cliente {cliente['nome']}")

        dados_api = self.api.buscar_cliente(cliente["cpf"])

        cliente_processado = {
            "nome": cliente["nome"],
            "cpf": cliente["cpf"],
            "status": dados_api["status"],
        }

        self.repository.salvar(cliente_processado)
