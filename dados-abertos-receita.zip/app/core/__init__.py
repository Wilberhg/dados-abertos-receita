from app.core.paths import assegura_criacao_diretorios

assegura_criacao_diretorios()
